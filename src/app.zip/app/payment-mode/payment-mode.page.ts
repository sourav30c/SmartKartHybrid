import { Component, OnInit } from '@angular/core';
import { UtilityService } from '../api/utility.service';
import { AlertController, Events, NavController, ModalController, MenuController } from '@ionic/angular';
import { Router, ActivatedRoute } from '@angular/router';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx'

@Component({
  selector: 'app-payment-mode',
  templateUrl: './payment-mode.page.html',
  styleUrls: ['./payment-mode.page.scss'],
})
export class PaymentModePage implements OnInit {
  totalCost = ""
  subtotalCost = ""
  cartInfoId = ""
  iscodLimit:boolean 
  isCode = "2"
  userToken: any
  data: any
  codLimitValue = 0
  delivryCharge = 0
  constructor(private util: UtilityService, public alertController: AlertController,
    public events: Events, private navCtrl: NavController, private route: Router, 
    public modalController: ModalController, private activeroute: ActivatedRoute, 
    private menuCtrl: MenuController, private iab: InAppBrowser) { 

    this.totalCost = this.route.getCurrentNavigation().extras.state.parms
    this.subtotalCost = this.route.getCurrentNavigation().extras.state.parms
    this.cartInfoId = this.route.getCurrentNavigation().extras.state.parms1

    this.codLimitValue = Number(localStorage.getItem('codLimit'))
    this.delivryCharge = Number(localStorage.getItem('delivryCharge'))

    console.log("cod limit comparison" , this.totalCost , this.codLimitValue) 

    if( Number(this.totalCost) <= Number(this.codLimitValue)){
      this.iscodLimit = true
    }else{
      this.iscodLimit = false
    }


    if (localStorage.getItem('userToken') != null) {
      this.userToken = JSON.parse(localStorage.getItem('userToken'))
      console.log("user token",this.userToken)
    }else{
      this.util.showToast('No User Token fetched. Try again.');
    }

  }

  ngOnInit() {
  }

  paymentMode(ev) {
    if (ev.detail.value == "1"){
      this.isCode = "1"
      this.totalCost = String(Number(this.subtotalCost) + this.delivryCharge)
    }else{
      this.isCode = "2"
      this.totalCost = this.subtotalCost
    }
    console.log("radio ev", ev.detail.value , this.isCode)
  }

  toPayment(){
    if(this.isCode == "1"){
      this.postDataCod()
    }else if(this.isCode == "2"){
      this.postDataOnline()
      //this.showFILE('https://www.smartkart.online/api/carts/ccavenuePayment/'+this.userToken)
    }
  }

  showFILE(url) {
    const browser = this.iab.create(url, '_blank', 'location=yes,toolbar=yes');
    console.log("browser", browser , url)
    browser.on('loadstop').subscribe(event => {
      console.log("loadstop -->", event);
      setInterval(() => this.getStateSecondWindow(browser), 5000);
    }, err => {
      console.log("InAppbrowser loadstop Event Error: " + err);
    });

    browser.on('loaderror').subscribe(event => {
      console.log("loaderror -->", event);
    }, err => {
      console.log("InAppbrowser loaderror Event Error: " + err);
    });

    browser.on('exit').subscribe(event => {
      console.log("exit -->", event);
    }, err => {
      console.log("InAppbrowser exit Event Error: " + err);
    });

    browser.show();

  }

  getStateSecondWindow(browser) {
    console.log('call now');
    browser.executeScript(
      {
        code: "localStorage.getItem('isCloseSelf')" //"localStorage.getItem('isCloseSelf')"
      },
      function (data) {
        console.log("data test function");
        console.log(data)
        browser.close();
        if (data == 'yes') {
          this.navCtrl.navigateForward('/thank-you')
        }else if (data == 'failed'){
          this.util.showToast('Payment is unsuccessful. Please Try again.');
          this.navCtrl.navigateForward('/cart')
        }else{
          this.util.showToast('Payment is unsuccessful. Please Try again.');
          this.navCtrl.navigateForward('/cart')
        }
      }
    );

  }

  postDataOnline(){
    var myData = JSON.stringify({
      info_id:String(this.cartInfoId),
      delivary_mode:"1"
    });
    console.log("Your myData: ", myData); //carts/freePayment.json
    this.util.presentLoading();
    this.util.getTypeDetailsWithAuth('carts/setDelivaryMode.json', myData).subscribe(result => {
      this.util.dismissLoader();
      console.log("Your data: ", result);
      this.data = result;
      if (this.data.success) {
        this.showFILE('https://www.smartkart.online/api/carts/ccavenuePayment/'+this.userToken)
      } else {
        this.util.showToast(this.data.message);
      }
    },
      error => {
        this.util.dismissLoader();
        this.util.showToast('Server error occured. Try again.');
      }
    );
  }

  postDataCod(){
    var myData = JSON.stringify({
      info_id:String(this.cartInfoId),
      delivary_mode:"2"
    });
    console.log("Your myData: ", myData); //carts/freePayment.json
    this.util.presentLoading();
    this.util.getTypeDetailsWithAuth('carts/setDelivaryMode.json', myData).subscribe(result => {
      this.util.dismissLoader();
      console.log("Your data: ", result);
      this.data = result;
      if (this.data.success) {
        //this.util.showAlert("Thank You", this.data.data)
        //this.showFILE('https://www.smartkart.online/api/carts/ccavenuePayment/'+this.userToken)
        this.postDataCodPost()
        //this.navCtrl.navigateForward('/thank-you')
      } else {
        this.util.showToast(this.data.message);
      }
    },
      error => {
        this.util.dismissLoader();
        this.util.showToast('Server error occured. Try again.');
      }
    );
  }

  postDataCodPost(){
    var myData = JSON.stringify({
    });
    console.log("Your myData: ", myData);
    this.util.presentLoading();
    this.util.getTypeDetailsWithAuth('carts/freePayment.json', myData).subscribe(result => {
      this.util.dismissLoader();
      console.log("Your data: ", result);
      this.data = result;
      if (this.data.success) {
        //this.util.showAlert("Thank You", this.data.data)
        this.navCtrl.navigateForward('/thank-you')
      } else {
        this.util.showToast(this.data.message);
      }
    },
      error => {
        this.util.dismissLoader();
        this.util.showToast('Server error occured. Try again.');
      }
    );
  }
}
